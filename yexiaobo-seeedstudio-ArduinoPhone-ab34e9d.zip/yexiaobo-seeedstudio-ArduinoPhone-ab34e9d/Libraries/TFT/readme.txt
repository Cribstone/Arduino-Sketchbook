The libraries TFT and TouchScreen for Arduino 1.0 IDE:

If you want it works on the MEGA board or MEGA2560,you should change the 29 line #define SEEEDUINO to #define MEGA.